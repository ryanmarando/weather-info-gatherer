declare namespace Express {
    export interface Request {
        admin: any;
    }
}
