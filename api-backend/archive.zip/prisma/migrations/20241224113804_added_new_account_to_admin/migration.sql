-- AlterTable
ALTER TABLE "admin" ADD COLUMN     "is_new_account" BOOLEAN DEFAULT true;
