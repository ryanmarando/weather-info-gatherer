-- AlterTable
ALTER TABLE "weather_input" ADD COLUMN     "videoPath" TEXT;
