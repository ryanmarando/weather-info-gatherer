-- AlterTable
ALTER TABLE "weather_input" ALTER COLUMN "showsDamage" DROP NOT NULL;
