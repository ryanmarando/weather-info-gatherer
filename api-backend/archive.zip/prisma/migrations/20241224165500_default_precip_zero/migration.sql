-- AlterTable
ALTER TABLE "weather_input" ALTER COLUMN "precip_total" SET DEFAULT 0.0;
